# 🏨 酒店采购审批系统 - 服务器版

## 📁 项目结构

```
hotel-purchase-system/
├── README.md                 # 项目说明（本文件）
├── LEARNING.md              # 学习路径指南
├── DEPLOY.md                # 部署教程
│
├── frontend/                # 前端文件
│   └── index.html          # 主页面
│
├── backend/                 # 后端代码
│   ├── package.json        # 项目配置
│   ├── server.js           # 主程序入口
│   ├── config/
│   │   └── database.js     # 数据库配置
│   ├── routes/
│   │   ├── auth.js         # 登录注册接口
│   │   ├── applications.js # 采购申请接口
│   │   ├── users.js        # 用户管理接口
│   │   └── daily-counts.js # 人数记录接口
│   ├── models/
│   │   ├── User.js         # 用户模型
│   │   ├── Application.js  # 申请模型
│   │   └── DailyCount.js   # 人数模型
│   └── middleware/
│       └── auth.js         # 登录验证中间件
│
├── database/
│   └── init.sql            # 数据库初始化脚本
│
└── docs/
    ├── api.md              # API接口文档
    └── screenshots/        # 截图
```

---

## 🎯 系统功能

### 用户角色

| 角色 | 权限 |
|------|------|
| **采购员** | 提交申请、查看自己的申请 |
| **老板** | 审批、管理AI数据、备份 |
| **财务** | 报账、登记人数、导出报表 |
| **管理员** | 管理用户、系统设置 |

### 核心功能

- ✅ 用户登录/注册
- ✅ 采购申请提交
- ✅ AI价格分析
- ✅ AI用量分析
- ✅ 老板审批
- ✅ 财务报账
- ✅ 人数管理
- ✅ 数据导出
- ✅ 文件上传

---

## 🚀 快速开始

### 1. 安装 Node.js

下载地址：https://nodejs.org/
选择 LTS（长期支持）版本

验证安装：
```bash
node --version
npm --version
```

### 2. 安装 MySQL

下载地址：https://dev.mysql.com/downloads/mysql/
或使用宝塔面板一键安装

### 3. 克隆项目

```bash
cd 你想放项目的文件夹
git clone [项目地址]
cd hotel-purchase-system
```

### 4. 安装依赖

```bash
cd backend
npm install
```

### 5. 配置数据库

编辑 `backend/config/database.js`：
```javascript
module.exports = {
  host: 'localhost',
  user: 'root',
  password: '你的密码',
  database: 'hotel_purchase'
};
```

### 6. 初始化数据库

```bash
mysql -u root -p < database/init.sql
```

### 7. 启动服务

```bash
npm start
```

### 8. 访问系统

浏览器打开：http://localhost:3000

---

## 📖 详细文档

- [学习路径指南](./LEARNING.md) - 从零开始学习
- [部署教程](./DEPLOY.md) - 如何部署到服务器
- [API文档](./docs/api.md) - 接口说明

---

## 💡 技术栈

| 类型 | 技术 | 说明 |
|------|------|------|
| 前端 | HTML/CSS/JS | 原生技术，无框架依赖 |
| 后端 | Node.js + Express | 轻量级Web框架 |
| 数据库 | MySQL | 关系型数据库 |
| 认证 | JWT | Token认证 |
| 文件 | Multer | 文件上传处理 |

---

## 📞 技术支持

遇到问题可以：
1. 查看文档
2. 搜索错误信息
3. 继续询问我

祝您学习顺利！🎉
